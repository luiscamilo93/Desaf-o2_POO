/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaDAL;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class Conexion {
    
    private static final Logger log = Logger.getLogger(Conexion.class);
    Connection conectar = null;
    String usuario = "root";
    String contrasenia = "root";
    String bd = "Mediateca";
    String ip = "localhost";
    String puerto = "3307";
    
    String cadena = "jdbc:mysql://"+ip+":"+puerto+"/"+bd;
    
    public Connection estableceConexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, usuario, contrasenia);
            JOptionPane.showMessageDialog(null, "Conexión exitosa");
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al establecer conexion"+e.toString());
            log.error("Error"+e);
        }    
        return conectar;
    }
}
