/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CSeleccionarLibro {
    
    private static final Logger log = Logger.getLogger(CSeleccionarLibro.class);
    
    public void SeleccionarLibro(JTable paramTablaLibros, CLibro libro){
        
        try {
            int fila = paramTablaLibros.getSelectedRow();
            if(fila>=0){
                libro.setId(paramTablaLibros.getValueAt(fila, 0).toString());
                libro.setTitulo(paramTablaLibros.getValueAt(fila, 1).toString());
                libro.setAutor(paramTablaLibros.getValueAt(fila, 2).toString());
                libro.setPaginas(Integer.parseInt(paramTablaLibros.getValueAt(fila, 3).toString()));
                libro.setEditorial(paramTablaLibros.getValueAt(fila, 4).toString());
                libro.setIsbn(paramTablaLibros.getValueAt(fila, 5).toString());
                libro.setAnio(Integer.parseInt(paramTablaLibros.getValueAt(fila, 6).toString()));
                libro.setUnidades(Integer.parseInt(paramTablaLibros.getValueAt(fila, 7).toString()));
            }
            else{
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de seleccion: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
    
}
