/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import mediateca_poo.mediatecaDAL.Conexion;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CRevista extends CMaterialEscrito {
    
    private static final Logger log = Logger.getLogger(CRevista.class);
    
    public String periodicidad;
    public String fecha;

    public CRevista(String id, String titulo, int unidades, String editorial, String periodicidad, String fecha) {
        super(id, titulo, unidades, editorial);
        this.periodicidad = periodicidad;
        this.fecha = fecha;
    }
    
    public String getPeriodicidad() {
        return periodicidad;
    }

    public void setPeriodicidad(String periodicidad) {
        this.periodicidad = periodicidad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public void InsertarRevista(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "insert into Revistas (id, titulo, editorial, periodicidad, fecha, unidades) values(?,?,?,?,?,?);";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getId());
            cs.setString(2, super.getTitulo());
            cs.setString(3, super.getEditorial());
            cs.setString(4, getPeriodicidad());
            cs.setString(5, getFecha());
            cs.setInt(6, super.getUnidades());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se insertó correctamente la revista");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se insertó la revista"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
    
    public void ModificarRevista(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "UPDATE Revistas SET titulo = ?, editorial = ?, periodicidad = ?, fecha = ?, unidades = ? WHERE id = ?;";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getTitulo());
            cs.setString(2, super.getEditorial());
            cs.setString(3, getPeriodicidad());
            cs.setString(4, getFecha());
            cs.setInt(5, super.getUnidades());
            cs.setString(6, super.getId());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se modificó correctamente la revista");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se modificó la revista"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
}
