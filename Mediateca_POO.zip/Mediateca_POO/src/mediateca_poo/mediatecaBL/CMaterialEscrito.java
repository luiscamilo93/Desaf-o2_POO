/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

/**
 *
 * @author camil
 */
public class CMaterialEscrito extends CMaterial {
    public String editorial;

    public CMaterialEscrito(String id, String titulo, int unidades, String editorial) {
        super(id, titulo, unidades);
        this.editorial = editorial;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }
}
