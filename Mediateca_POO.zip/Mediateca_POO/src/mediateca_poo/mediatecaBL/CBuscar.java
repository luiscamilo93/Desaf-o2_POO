/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import mediateca_poo.mediatecaDAL.Conexion;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CBuscar {
    
    private static final Logger log = Logger.getLogger(CBuscar.class);
    
    public void BuscarLibro(JTable paramTablaTotalMateriales, String titulo){
    
        Conexion objetoConexion = new Conexion();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        paramTablaTotalMateriales.setRowSorter(OrdenarTabla);
        
        String sql="";
        
        modelo.addColumn("ID");
        modelo.addColumn("Titulo");
        modelo.addColumn("Autor");
        modelo.addColumn("Paginas");
        modelo.addColumn("Editorial");
        modelo.addColumn("ISBN");
        modelo.addColumn("Año");
        modelo.addColumn("Unidades");
        
        paramTablaTotalMateriales.setModel(modelo);
        
        sql = "select * from Libros where titulo = ?;";
        
        String[] lista = new String[8];
        
        try {
            
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(sql);
            
            cs.setString(1, titulo);
            
            ResultSet rs = cs.executeQuery();
            
            while(rs.next()){
            
                lista[0]=rs.getString(1);
                lista[1]=rs.getString(2);
                lista[2]=rs.getString(3);
                lista[3]=rs.getString(4);
                lista[4]=rs.getString(5);
                lista[5]=rs.getString(6);
                lista[6]=rs.getString(7);
                lista[7]=rs.getString(8);
                
                modelo.addRow(lista);
            }
                    
                paramTablaTotalMateriales.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"No se pudo mostrar los registros, error: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
    
    public void BuscarRevista(JTable paramTablaTotalMateriales, String titulo){
    
        Conexion objetoConexion = new Conexion();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        paramTablaTotalMateriales.setRowSorter(OrdenarTabla);
        
        String sql="";
        
        modelo.addColumn("ID");
        modelo.addColumn("Titulo");
        modelo.addColumn("Editorial");
        modelo.addColumn("Periodicidad");
        modelo.addColumn("Fecha");
        modelo.addColumn("Unidades");
        
        paramTablaTotalMateriales.setModel(modelo);
        
        sql = "select * from Revistas where titulo = ?;";
        
        String[] lista = new String[6];
        
        try {
            
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(sql);
            
            cs.setString(1, titulo);
            
            ResultSet rs = cs.executeQuery();
            
            while(rs.next()){
            
                lista[0]=rs.getString(1);
                lista[1]=rs.getString(2);
                lista[2]=rs.getString(3);
                lista[3]=rs.getString(4);
                lista[4]=rs.getString(5);
                lista[5]=rs.getString(6);
                
                modelo.addRow(lista);
            }
                    
                paramTablaTotalMateriales.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"No se pudo mostrar los registros, error: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
    
    public void BuscarCD(JTable paramTablaTotalMateriales, String titulo){
    
        Conexion objetoConexion = new Conexion();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        paramTablaTotalMateriales.setRowSorter(OrdenarTabla);
        
        String sql="";
        
        modelo.addColumn("ID");
        modelo.addColumn("Titulo");
        modelo.addColumn("Artista");
        modelo.addColumn("Genero");
        modelo.addColumn("Duracion");
        modelo.addColumn("Canciones");
        modelo.addColumn("Unidades");
        
        paramTablaTotalMateriales.setModel(modelo);
        
        sql = "select * from CDs where titulo = ?;";
        
        String[] lista = new String[7];
        
        try {
            
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(sql);
            
            cs.setString(1, titulo);
            
            ResultSet rs = cs.executeQuery();
            
            while(rs.next()){
            
                lista[0]=rs.getString(1);
                lista[1]=rs.getString(2);
                lista[2]=rs.getString(3);
                lista[3]=rs.getString(4);
                lista[4]=rs.getString(5);
                lista[5]=rs.getString(6);
                lista[6]=rs.getString(7);
                
                modelo.addRow(lista);
            }
                    
                paramTablaTotalMateriales.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"No se pudo mostrar los registros, error: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
    
    public void BuscarDVD(JTable paramTablaTotalMateriales, String titulo){
    
        Conexion objetoConexion = new Conexion();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        
        paramTablaTotalMateriales.setRowSorter(OrdenarTabla);
        
        String sql="";
        
        modelo.addColumn("ID");
        modelo.addColumn("Titulo");
        modelo.addColumn("Director");
        modelo.addColumn("Duracion");
        modelo.addColumn("Genero");
        modelo.addColumn("Unidades");
        
        paramTablaTotalMateriales.setModel(modelo);
        
        sql = "select * from DVDs where titulo = ?;";
        
        String[] lista = new String[6];
        
        
        try {
            
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(sql);
            
            cs.setString(1, titulo);
            
            ResultSet rs = cs.executeQuery();
            
            while(rs.next()){
            
                lista[0]=rs.getString(1);
                lista[1]=rs.getString(2);
                lista[2]=rs.getString(3);
                lista[3]=rs.getString(4);
                lista[4]=rs.getString(5);
                lista[5]=rs.getString(6);
                
                modelo.addRow(lista);
            }
                    
                paramTablaTotalMateriales.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"No se pudo mostrar los registros, error: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
}
