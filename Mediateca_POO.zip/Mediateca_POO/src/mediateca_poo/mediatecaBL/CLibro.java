/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import mediateca_poo.mediatecaDAL.Conexion;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CLibro extends CMaterialEscrito{
    
    private static final Logger log = Logger.getLogger(CLibro.class);
    
    public String autor;
    public int paginas;
    public String isbn;
    public int anio;

    
    public CLibro(String id, String titulo, int unidades, String editorial, String autor, int paginas, String isbn, int anio) {
        super(id, titulo, unidades, editorial);
        this.autor = autor;
        this.paginas = paginas;
        this.isbn = isbn;
        this.anio = anio;
    }
    

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public void InsertarLibro(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "insert into Libros (id, titulo, autor, paginas, editorial, isbn, anio, unidades) values(?,?,?,?,?,?,?,?);";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getId());
            cs.setString(2, super.getTitulo());
            cs.setString(3, getAutor());
            cs.setInt(4, getPaginas());
            cs.setString(5, super.getEditorial());
            cs.setString(6, getIsbn());
            cs.setInt(7, getAnio());
            cs.setInt(8, super.getUnidades());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se insertó correctamente el libro");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se insertó el libro"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
    
    public void ModificarLibro(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "UPDATE Libros SET titulo = ?, autor = ?, paginas = ?, editorial = ?, isbn = ?, anio = ?, unidades = ? WHERE id = ?;";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getTitulo());
            cs.setString(2, getAutor());
            cs.setInt(3, getPaginas());
            cs.setString(4, super.getEditorial());
            cs.setString(5, getIsbn());
            cs.setInt(6, getAnio());
            cs.setInt(7, super.getUnidades());
            cs.setString(8, super.getId());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se modificó correctamente el libro");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se modificó el libro"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
}
