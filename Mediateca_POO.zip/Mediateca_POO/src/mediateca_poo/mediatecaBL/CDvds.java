/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import mediateca_poo.mediatecaDAL.Conexion;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CDvds extends CMaterialAudiovisual{
    
    private static final Logger log = Logger.getLogger(CDvds.class);
    
    public String director;
    
    public CDvds (String id, String titulo, int unidades, int duracion, String genero, String director) {
        super(id, titulo, unidades, duracion, genero);
        this.director = director;
    }
    
    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }
    
    public void InsertarDVD(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "insert into DVDs (id, titulo, director, duracion, genero, unidades) values(?,?,?,?,?,?);";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getId());
            cs.setString(2, super.getTitulo());
            cs.setString(3, getDirector());
            cs.setInt(4, super.getDuracion());
            cs.setString(5, super.getGenero());
            cs.setInt(6, super.getUnidades());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se insertó correctamente el DVD");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se insertó el DVD"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
    
    public void ModificarDVD(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "UPDATE DVDs SET titulo = ?, director = ?, duracion = ?, genero = ?, unidades = ? WHERE id = ?;";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getTitulo());
            cs.setString(2, getDirector());
            cs.setInt(3, super.getDuracion());
            cs.setString(4, super.getGenero());
            cs.setInt(5, super.getUnidades());
            cs.setString(6, super.getId());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se modificó correctamente el DVD");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se modificó el DVD"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
}
