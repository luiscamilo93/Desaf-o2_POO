/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CSeleccionarDVD {
    
    private static final Logger log = Logger.getLogger(CSeleccionarDVD.class);
    
    public void SeleccionarDVD(JTable paramTablaDVDs, CDvds dvd){
        
        try {
            int fila = paramTablaDVDs.getSelectedRow();
            if(fila>=0){
                dvd.setId(paramTablaDVDs.getValueAt(fila, 0).toString());
                dvd.setTitulo(paramTablaDVDs.getValueAt(fila, 1).toString());
                dvd.setDirector(paramTablaDVDs.getValueAt(fila, 2).toString());
                dvd.setDuracion(Integer.parseInt(paramTablaDVDs.getValueAt(fila, 3).toString()));
                dvd.setGenero(paramTablaDVDs.getValueAt(fila, 4).toString());
                dvd.setUnidades(Integer.parseInt(paramTablaDVDs.getValueAt(fila, 5).toString()));
            }
            else{
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de seleccion: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
    
}
