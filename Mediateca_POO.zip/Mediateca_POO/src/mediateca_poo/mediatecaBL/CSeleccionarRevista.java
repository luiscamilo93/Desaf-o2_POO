/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CSeleccionarRevista {
    
    private static final Logger log = Logger.getLogger(CSeleccionarRevista.class);
    
    public void SeleccionarRevista(JTable paramTablaRevista, CRevista revista){
        
        try {
            int fila = paramTablaRevista.getSelectedRow();
            if(fila>=0){
                revista.setId(paramTablaRevista.getValueAt(fila, 0).toString());
                revista.setTitulo(paramTablaRevista.getValueAt(fila, 1).toString());
                revista.setEditorial(paramTablaRevista.getValueAt(fila, 2).toString());
                revista.setPeriodicidad(paramTablaRevista.getValueAt(fila, 3).toString());
                revista.setFecha(paramTablaRevista.getValueAt(fila, 4).toString());
                revista.setUnidades(Integer.parseInt(paramTablaRevista.getValueAt(fila, 5).toString()));
            }
            else{
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de seleccion: "+e.toString());
            log.error("Mensaje de error: "+e);
        }
        
    }
    
}
