/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import mediateca_poo.mediatecaDAL.Conexion;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CBorrar {
    
    private static final Logger log = Logger.getLogger(CBorrar.class);
    
    public void BorrarMaterial(JTable paramTablaMaterial, String tipo){
        String id;
        try {
            int fila = paramTablaMaterial.getSelectedRow();
            
            if(fila>=0){
                
                Conexion objetoConexion = new Conexion();
        
                String consulta = "DELETE FROM $table_name WHERE id = ?;";
                
                String sql = consulta.replace("$table_name", tipo);
                
                id= paramTablaMaterial.getValueAt(fila, 0).toString();
                
                try {
                    CallableStatement cs = objetoConexion.estableceConexion().prepareCall(sql);
            
                    cs.setString(1, id);
            
                    cs.execute();
            
                    JOptionPane.showMessageDialog(null, "Se borró correctamente el material");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "No se borró el material"+e.toString());
                    log.info("Mensaje de error"+e);
                }
            }    
            else{
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }   
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de seleccion: "+e.toString());
            log.error("Mensaje de error: " + e);
        }
    }
    
    
    
}
