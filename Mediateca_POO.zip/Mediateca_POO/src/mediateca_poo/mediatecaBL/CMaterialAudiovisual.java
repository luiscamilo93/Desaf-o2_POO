/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

/**
 *
 * @author camil
 */
public class CMaterialAudiovisual extends CMaterial{
    public int duracion;
    public String genero;

    public CMaterialAudiovisual (String id, String titulo, int unidades, int duracion, String genero) {
        super(id, titulo, unidades);
        this.duracion = duracion;
        this.genero = genero;
    }
    
    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }    
}
