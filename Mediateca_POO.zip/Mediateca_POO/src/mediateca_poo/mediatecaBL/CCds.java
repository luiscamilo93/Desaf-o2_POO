/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca_poo.mediatecaBL;

import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import mediateca_poo.mediatecaDAL.Conexion;
import org.apache.log4j.Logger;

/**
 *
 * @author camil
 */
public class CCds extends CMaterialAudiovisual{
    
    private static final Logger log = Logger.getLogger(CCds.class);
    
    public String artista;
    public int canciones;

    public CCds (String id, String titulo, int unidades, int duracion, String genero, String artista, int canciones) {
        super(id, titulo, unidades, duracion, genero);
        this.artista = artista;
        this.canciones = canciones;
    }
    
    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getCanciones() {
        return canciones;
    }

    public void setCanciones(int canciones) {
        this.canciones = canciones;
    }
    
    public void InsertarCD(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "insert into CDs (id, titulo, artista, genero, duracion, canciones, unidades) values(?,?,?,?,?,?,?);";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getId());
            cs.setString(2, super.getTitulo());
            cs.setString(3, getArtista());
            cs.setString(4, super.getGenero());
            cs.setInt(5, super.getDuracion());
            cs.setInt(6, getCanciones());
            cs.setInt(7, super.getUnidades());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se insertó correctamente el CD");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se insertó el CD"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
    
    public void ModificarCD(){
        
        Conexion objetoConexion = new Conexion();
        
        String consulta = "UPDATE CDs SET titulo = ?, artista = ?, genero = ?, duracion = ?, canciones = ?, unidades = ? WHERE id = ?;";
        
        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1, super.getTitulo());
            cs.setString(2, getArtista());
            cs.setString(3, super.getGenero());
            cs.setInt(4, super.getDuracion());
            cs.setInt(5, getCanciones());
            cs.setInt(6, super.getUnidades());
            cs.setString(7, super.getId());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se modificó correctamente el CD");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se modificó el CD"+e.toString());
            log.error("Mensaje de error: "+e);
        }
    }
    
    
}
